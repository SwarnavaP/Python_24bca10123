const courseGrid = document.getElementById('course-grid');
const courseSelect = document.getElementById('course-select');
const messageBox = document.getElementById('message');
let courses = [];

async function loadDashboard() {
  const response = await fetch('/api/dashboard');
  const data = await response.json();
  courses = data.course_list;
  document.getElementById('student-count').textContent = data.students;
  document.getElementById('course-count').textContent = data.courses;
  document.getElementById('registration-count').textContent = data.registrations;
  renderCourses(courses);
  renderCourseOptions(courses);
}

function renderCourses(list) {
  courseGrid.innerHTML = '';
  if (!list.length) {
    courseGrid.innerHTML = '<p class="empty-state">No courses match your search.</p>';
    return;
  }
  const icons = {violet:'⌘', blue:'⌁', orange:'▦', green:'⌖', pink:'✦'};
  list.forEach(course => {
    const percentage = Math.min(100, (course.enrolled / course.capacity) * 100);
    const full = course.available <= 0;
    const card = document.createElement('article');
    card.className = 'course-card';
    card.innerHTML = `
      <div class="course-top"><span class="course-code">${course.id}</span><span class="course-art art-${course.color}">${icons[course.color] || '▤'}</span></div>
      <h3>${escapeHTML(course.name)}</h3><p class="department">${escapeHTML(course.department)}</p>
      <div class="course-meta"><span>◷ ${course.credits} credits</span><span>♙ ${course.capacity} seats</span></div>
      <div class="capacity-row"><span>Enrollment</span><b class="${full ? 'full-label' : ''}">${full ? 'Course full' : `${course.available} seats left`}</b></div>
      <div class="progress"><span style="width:${percentage}%"></span></div>`;
    courseGrid.appendChild(card);
  });
}

function renderCourseOptions(list) {
  courseSelect.innerHTML = '<option value="">Choose a course</option>';
  list.forEach(course => {
    const option = document.createElement('option');
    option.value = course.id;
    option.textContent = `${course.id} — ${course.name}${course.available <= 0 ? ' (Full)' : ` (${course.available} seats left)`}`;
    option.disabled = course.available <= 0;
    courseSelect.appendChild(option);
  });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

document.getElementById('search').addEventListener('input', event => {
  const query = event.target.value.toLowerCase();
  renderCourses(courses.filter(course => `${course.name} ${course.id} ${course.department}`.toLowerCase().includes(query)));
});

document.getElementById('registration-form').addEventListener('submit', async event => {
  event.preventDefault();
  messageBox.textContent = '';
  messageBox.className = 'message';
  const payload = {
    student_id: document.getElementById('student-id').value.trim(),
    name: document.getElementById('student-name').value.trim(),
    course_id: courseSelect.value
  };
  const response = await fetch('/api/register', {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)
  });
  const result = await response.json();
  messageBox.textContent = result.message || result.error;
  messageBox.classList.add(response.ok ? 'success' : 'error');
  if (response.ok) {
    document.getElementById('lookup-id').value = payload.student_id;
    await loadDashboard();
    await showMyCourses(payload.student_id);
  }
});

async function showMyCourses(studentId) {
  const list = document.getElementById('my-course-list');
  list.innerHTML = '';
  const response = await fetch(`/api/students/${encodeURIComponent(studentId)}/courses`);
  const data = await response.json();
  if (!response.ok) {
    list.innerHTML = `<div class="empty-state"><p>${escapeHTML(data.error)}</p></div>`;
    return;
  }
  if (!data.courses.length) {
    list.innerHTML = '<div class="empty-state"><p>No courses registered yet.</p></div>';
    return;
  }
  data.courses.forEach(course => {
    const item = document.createElement('div');
    item.className = 'registered-item';
    item.innerHTML = `<div><strong>${escapeHTML(course.name)}</strong><small>${course.id} · ${course.credits} credits</small></div><button class="drop-button" data-course="${course.id}">Drop</button>`;
    item.querySelector('button').addEventListener('click', () => dropCourse(studentId, course.id));
    list.appendChild(item);
  });
}

document.getElementById('lookup-form').addEventListener('submit', event => {
  event.preventDefault();
  showMyCourses(document.getElementById('lookup-id').value.trim());
});

async function dropCourse(studentId, courseId) {
  const response = await fetch('/api/drop', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({student_id: studentId, course_id: courseId})
  });
  const data = await response.json();
  messageBox.textContent = data.message || data.error;
  messageBox.className = `message ${response.ok ? 'success' : 'error'}`;
  if (response.ok) {
    await loadDashboard();
    await showMyCourses(studentId);
  }
}

loadDashboard().catch(() => {
  courseGrid.innerHTML = '<p class="empty-state">Could not connect to the Python server. Please restart the app.</p>';
});
