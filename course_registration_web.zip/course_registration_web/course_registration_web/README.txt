COURSE REGISTRATION WEB APP

Files:
- app.py: Python Flask backend and registration rules
- templates/index.html: webpage structure
- static/style.css: dashboard styling and responsive layout
- static/script.js: webpage interactions and API requests
- registrations.json: created automatically when the first student registers

RUN IT ON WINDOWS:
1. Install Python if it is not already installed.
2. Open Command Prompt or the VS Code terminal in this folder.
3. Run: py -m pip install -r requirements.txt
4. Run: py app.py
5. Open this address in your browser: http://127.0.0.1:5000

The app stores registration information in registrations.json. Keep app.py running while using the webpage.
