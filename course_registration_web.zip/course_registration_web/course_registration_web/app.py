from flask import Flask, render_template, request, jsonify
import json
from pathlib import Path

app = Flask(__name__)
DATA_FILE = Path(__file__).with_name("registrations.json")

COURSES = [
    {"id": "C101", "name": "Python Programming", "department": "Computer Science", "credits": 4, "capacity": 3, "enrolled": 0, "color": "violet"},
    {"id": "C102", "name": "Data Structures", "department": "Computer Science", "credits": 3, "capacity": 2, "enrolled": 0, "color": "blue"},
    {"id": "C103", "name": "Database Management", "department": "Information Technology", "credits": 4, "capacity": 3, "enrolled": 0, "color": "orange"},
    {"id": "C104", "name": "Computer Networks", "department": "Information Technology", "credits": 3, "capacity": 2, "enrolled": 0, "color": "green"},
    {"id": "C105", "name": "Software Engineering", "department": "Computer Science", "credits": 3, "capacity": 3, "enrolled": 0, "color": "pink"}
]


def load_registrations():
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return []
    return []


def save_registrations(registrations):
    DATA_FILE.write_text(json.dumps(registrations, indent=2), encoding="utf-8")


def course_status(registrations):
    courses = [course.copy() for course in COURSES]
    for course in courses:
        course["enrolled"] = sum(course["id"] in student["courses"] for student in registrations)
        course["available"] = course["capacity"] - course["enrolled"]
    return courses


@app.route("/")
def home():
    return render_template("index.html")


@app.get("/api/dashboard")
def dashboard():
    registrations = load_registrations()
    courses = course_status(registrations)
    return jsonify({
        "students": len(registrations),
        "courses": len(courses),
        "registrations": sum(len(student["courses"]) for student in registrations),
        "course_list": courses
    })


@app.get("/api/students/<student_id>/courses")
def get_student_courses(student_id):
    registrations = load_registrations()
    student = next((s for s in registrations if s["student_id"] == student_id), None)
    if not student:
        return jsonify({"error": "Student not found."}), 404
    courses = course_status(registrations)
    selected = [c for c in courses if c["id"] in student["courses"]]
    return jsonify({"student": student, "courses": selected})


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    student_id = str(data.get("student_id", "")).strip()
    name = str(data.get("name", "")).strip()
    course_id = str(data.get("course_id", "")).strip()

    if not student_id or not name or not course_id:
        return jsonify({"error": "Enter your student ID, name, and choose a course."}), 400

    registrations = load_registrations()
    student = next((s for s in registrations if s["student_id"] == student_id), None)
    if student and student["name"].casefold() != name.casefold():
        return jsonify({"error": "This student ID is already registered with another name."}), 400
    if not student:
        student = {"student_id": student_id, "name": name, "courses": []}
        registrations.append(student)

    course = next((c for c in COURSES if c["id"] == course_id), None)
    if not course:
        return jsonify({"error": "Course not found."}), 404
    if course_id in student["courses"]:
        return jsonify({"error": "You are already registered for this course."}), 400
    if len(student["courses"]) >= 3:
        return jsonify({"error": "You can register for a maximum of 3 courses."}), 400

    current_count = sum(course_id in s["courses"] for s in registrations)
    if current_count >= course["capacity"]:
        return jsonify({"error": "This course is full. Please choose another course."}), 400

    student["courses"].append(course_id)
    save_registrations(registrations)
    return jsonify({"message": f"Successfully registered for {course['name']}!"})


@app.post("/api/drop")
def drop_course():
    data = request.get_json(silent=True) or {}
    student_id = str(data.get("student_id", "")).strip()
    course_id = str(data.get("course_id", "")).strip()
    registrations = load_registrations()
    student = next((s for s in registrations if s["student_id"] == student_id), None)
    if not student or course_id not in student["courses"]:
        return jsonify({"error": "Registration could not be found."}), 404
    student["courses"].remove(course_id)
    save_registrations(registrations)
    return jsonify({"message": "Course dropped successfully."})


if __name__ == "__main__":
    app.run(debug=True)
